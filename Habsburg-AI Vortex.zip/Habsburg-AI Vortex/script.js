// ================== CONFIG ==================
const OLLAMA_CHAT_URL = "http://localhost:11434/api/chat";
const OLLAMA_MODEL = "ministral-3:3b";
const ITERATIONS = 5;

// Performance controls (tune these first)
const TARGET_FPS = 30;
const MAX_TURNS = 10;                // fewer rings = faster
const MAX_TOKENS_PER_TURN = 220;     // cap text draw calls per ring
const BG_ALPHA = 0.22;               // higher = less trail (often feels faster)
const TWIST_SPEED = 0.004;

// Typography
const FONT_STACK = `"Arial Black", Impact, system-ui, -apple-system, Segoe UI, Roboto, sans-serif`;
const INNER_FONT = 10;
const OUTER_FONT = 32;

// Only apply expensive effects above these sizes
const STROKE_MIN_FONT = 16;
const SHADOW_MIN_FONT = 18;

// Your system prompt (verbatim rules)
const SYSTEM_PROMPT = `You are a text-distortion engine. You will receive a user sentence between tags. Output exactly one distorted sentence (one line) that is a degraded/misheard version of the input: simplify wording, drop 20–40% of details, introduce 1–2 subtle misunderstandings, and slightly fragment the grammar while keeping it readable.
Hard rules:

Output only the final distorted sentence.

No preface, no explanations, no bullets, no quotes, no code fences.

No “thinking”, no reasoning, no metadata.

Keep it in the same language as the input.`;

// Per-sequence colors
const SEQ_COLORS = [
  "#00E5FF",
  "#FF2D95",
  "#FFE600",
  "#7CFF00",
  "#FF8A00",
  "#9B5CFF",
  "#00FFB3",
  "#FF3B3B",
];
function colorForSequence(sequenceId) {
  return SEQ_COLORS[(sequenceId - 1) % SEQ_COLORS.length];
}
function hexToRgb(hex) {
  const h = (hex || "#ffffff").replace("#", "");
  const full = h.length === 3 ? h.split("").map(c => c + c).join("") : h;
  const n = parseInt(full, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

// ================== STATE ==================
let textLines = []; // { id, text, iteration, sequenceId, color, rgb, _tokensKey, _tokens }
let rotation = 0;
let isLoading = false;
let sequenceCount = 0;

// ================== DOM ==================
const canvas = document.getElementById("vortexCanvas");
const ctx = canvas.getContext("2d");

const inputEl = document.getElementById("inputText");
const buttonEl = document.getElementById("corruptButton");
const errorEl = document.getElementById("errorBox");
const totalEl = document.getElementById("totalCorruptions");
const activeEl = document.getElementById("activeSequences");

const panelToggle = document.getElementById("panelToggle");
const controlPanel = document.getElementById("controlPanel");
const panelToggleArrow = document.getElementById("panelToggleArrow");

// ================== CANVAS SIZE ==================
function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener("resize", resizeCanvas);

// ================== UI HELPERS ==================
function showError(message) {
  if (!message) {
    errorEl.textContent = "";
    errorEl.classList.add("hidden");
    return;
  }
  errorEl.textContent = message;
  errorEl.classList.remove("hidden");
}
function updateStats() {
  totalEl.textContent = String(textLines.length);
  activeEl.textContent = String(sequenceCount);
}
function setButtonProgress(step) {
  buttonEl.innerHTML =
    '<span class="spinner"></span>' +
    `<span>Corrupting... (${step}/${ITERATIONS})</span>`;
}
function setLoading(state) {
  isLoading = state;
  if (state) {
    buttonEl.disabled = true;
    setButtonProgress(0);
  } else {
    buttonEl.textContent = "BEGIN CORRUPTION";
    buttonEl.disabled = inputEl.value.trim().length === 0;
  }
}
inputEl.addEventListener("input", () => {
  if (isLoading) return;
  buttonEl.disabled = inputEl.value.trim().length === 0;
});

// Dropdown toggle
panelToggle.addEventListener("click", () => {
  const isCollapsed = controlPanel.classList.toggle("collapsed");
  panelToggleArrow.textContent = isCollapsed ? "▼" : "▲";
});

// ================== TEXT SANITIZE ==================
function sanitizeOneLine(text) {
  let t = (text || "").trim();
  const firstLine = t
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)[0];

  t = (firstLine || "…").trim();
  t = t.replace(/^["'`]+/, "").replace(/["'`]+$/, "");
  t = t.replace(/^[-•\u2022]+\s*/, "");
  return t || "…";
}

// ================== LOCAL FALLBACK ==================
function localCorruption(text, iteration) {
  let result = text;
  const intensity = Math.min(iteration + 1, ITERATIONS);

  result = result
    .split("")
    .filter(() => Math.random() > 0.06 * intensity)
    .join("");

  const glitches = ["#", "%", "@", "¿", "?", "!", "ø", "∆"];
  result = result
    .split("")
    .map((ch) =>
      Math.random() < 0.04 * intensity
        ? glitches[Math.floor(Math.random() * glitches.length)]
        : ch
    )
    .join("");

  if (intensity >= Math.ceil(ITERATIONS / 2)) {
    const words = result.split(/\s+/);
    for (let i = words.length - 1; i > 0; i--) {
      if (Math.random() < 0.35) {
        const j = Math.floor(Math.random() * (i + 1));
        [words[i], words[j]] = [words[j], words[i]];
      }
    }
    result = words.join(" ");
  }

  return sanitizeOneLine(result || "…");
}

// ================== OLLAMA DISTORTION ==================
async function ollamaCorruption(text) {
  const payload = {
    model: OLLAMA_MODEL,
    stream: true,
    keep_alive: "10m",
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: `<INPUT>${text}</INPUT>` }
    ],
    options: {
      temperature: 0.7,
      num_ctx: 2048,
      num_predict: 90
    }
  };

  const res = await fetch(OLLAMA_CHAT_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  if (!res.ok) throw new Error(`Ollama error: ${res.status}`);

  const reader = res.body?.getReader?.();
  if (!reader) {
    const data = await res.json();
    return sanitizeOneLine(data?.message?.content || data?.response || "");
  }

  const decoder = new TextDecoder();
  let full = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value, { stream: true });
    const lines = chunk.split("\n").map((s) => s.trim()).filter(Boolean);

    for (const line of lines) {
      try {
        const obj = JSON.parse(line);
        if (obj?.message?.content) full += obj.message.content;
        else if (obj?.response) full += obj.response;
      } catch {
        // ignore
      }
    }
  }

  return sanitizeOneLine(full);
}

// ================== MODEL CHECK ==================
async function modelExists(modelName) {
  try {
    const res = await fetch("http://localhost:11434/api/show", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: modelName })
    });

    // 404 => model not found
    if (res.status === 404) return false;

    // If other errors
    if (!res.ok) return false;

    // If JSON exists, model is valid
    const data = await res.json();
    return !!data;
  } catch (err) {
    // This means Ollama is not running or unreachable
    return false;
  }
}

async function corruptText(text, iteration) {
  try {
    return await ollamaCorruption(text);
  } catch (e) {
    console.error("Ollama failed, using local fallback:", e);
    return localCorruption(text, iteration);
  }
}

// ================== PROCESS INPUT (5 iterations, update each step) ==================
async function processInput() {
  const raw = inputEl.value.trim();
  if (!raw || isLoading) return;

  showError("");

  // ---- MODEL CHECK BEFORE ANYTHING RUNS ----
  const ok = await modelExists(OLLAMA_MODEL);
  if (!ok) {
    showError(`⚠️ Model "${OLLAMA_MODEL}" not found or Ollama not running.`);
    return;
  }

  setLoading(true);
  showError("");

  sequenceCount += 1;
  const sequenceId = sequenceCount;
  const seqColor = colorForSequence(sequenceId);
  const seqRgb = hexToRgb(seqColor);

  let currentText = raw;

  try {
    for (let i = 0; i < ITERATIONS; i++) {
      currentText = await corruptText(currentText, i);

      textLines.push({
        id: Date.now() + i,
        text: currentText,
        iteration: i + 1,
        sequenceId: sequenceId,
        color: seqColor,
        rgb: seqRgb,
        _tokensKey: "",
        _tokens: null
      });

      updateStats();
      setButtonProgress(i + 1);
    }

    inputEl.value = "";
  } catch (err) {
    console.error(err);
    showError("Failed to process text. Ensure Ollama is running and the model is available.");
  } finally {
    setLoading(false);
  }
}

buttonEl.addEventListener("click", processInput);
inputEl.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
    e.preventDefault();
    processInput();
  }
});

// ================== SPIRAL SELECTION ==================
function sampleLines(lines, max) {
  if (lines.length <= max) return lines;
  const res = [];
  const step = (lines.length - 1) / (max - 1);
  for (let i = 0; i < max; i++) {
    res.push(lines[Math.round(i * step)]);
  }
  return res;
}

// ================== DRAW: TEXT ON SPIRAL TURN ==================
const TWO_PI = Math.PI * 2;

function ensureTokens(line) {
  const base = (line.text || "").trim();
  if (line._tokensKey === base && line._tokens) return line._tokens;

  const tokens = base ? base.split(/\s+/).filter(Boolean) : ["…"];
  // separator helps readability
  const loopTokens = tokens.length ? tokens.concat(["•"]) : ["…", "•"];

  line._tokensKey = base;
  line._tokens = loopTokens;
  return loopTokens;
}

function drawTokenAt(x, y, ang, token, fontSize, alpha, rgb) {
  // rotate text tangent to spiral
  const rot = ang + Math.PI / 2;
  const ca = Math.cos(rot);
  const sa = Math.sin(rot);

  ctx.setTransform(ca, sa, -sa, ca, x, y);

  ctx.font = `800 ${fontSize}px ${FONT_STACK}`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  ctx.globalAlpha = alpha;

  // fill
  ctx.fillStyle = `rgb(${rgb.r},${rgb.g},${rgb.b})`;

  // optional shadow (expensive)
  if (fontSize >= SHADOW_MIN_FONT) {
    ctx.shadowBlur = 8 + (fontSize - SHADOW_MIN_FONT) * 0.6;
    ctx.shadowColor = `rgb(${rgb.r},${rgb.g},${rgb.b})`;
  } else {
    ctx.shadowBlur = 0;
  }

  // optional stroke (very expensive)
  if (fontSize >= STROKE_MIN_FONT) {
    ctx.lineWidth = Math.max(2, fontSize * 0.10);
    ctx.strokeStyle = "rgba(0,0,0,0.85)";
    ctx.strokeText(token, 0, 0);
  }

  ctx.fillText(token, 0, 0);
}

function drawSpiralTurn({ line, turnIndex, turnCount, minR, maxR, cx, cy }) {
  const tokens = ensureTokens(line);
  const rgb = line.rgb || hexToRgb(line.color || "#ffffff");

  const thetaStart = turnIndex * TWO_PI;
  const thetaEnd = (turnIndex + 1) * TWO_PI;
  const totalTheta = turnCount * TWO_PI;

  let theta = thetaStart;
  let ti = 0;
  let draws = 0;

  while (theta < thetaEnd && draws < MAX_TOKENS_PER_TURN) {
    const globalP = theta / totalTheta; // 0..1 center->outer
    const r = minR + globalP * (maxR - minR);

    const fontSize = INNER_FONT + globalP * (OUTER_FONT - INNER_FONT);
    const alpha = 0.10 + globalP * 0.90;

    const token = tokens[ti % tokens.length];

    const ang = theta + rotation;
    const x = cx + Math.cos(ang) * r;
    const y = cy + Math.sin(ang) * r;

    drawTokenAt(x, y, ang, token, fontSize, alpha, rgb);

    // cheaper spacing (no per-token measureText)
    const approxWidth = Math.max(1, token.length) * fontSize * 0.55;
    const dTheta = (approxWidth / Math.max(r, 1)) + 0.035;

    theta += dTheta;
    ti += 1;
    draws += 1;
  }
}

// ================== ANIMATION LOOP (THROTTLED) ==================
let lastFrameTs = 0;

function animate(ts) {
  const minDt = 1000 / TARGET_FPS;
  if (ts - lastFrameTs < minDt) {
    requestAnimationFrame(animate);
    return;
  }
  lastFrameTs = ts;

  const w = canvas.width;
  const h = canvas.height;

  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;

  ctx.fillStyle = `rgba(0,0,0,${BG_ALPHA})`;
  ctx.fillRect(0, 0, w, h);

  rotation += TWIST_SPEED;

  const cx = w / 2;
  const cy = h / 2;
  const minR = Math.min(w, h) * 0.050; // center hole
  const maxR = Math.min(w, h) * 0.49;

  const linesToDraw = sampleLines(textLines, MAX_TURNS);
  const turnCount = Math.max(1, linesToDraw.length);

  for (let i = 0; i < linesToDraw.length; i++) {
    drawSpiralTurn({
      line: linesToDraw[i],
      turnIndex: i,
      turnCount,
      minR,
      maxR,
      cx,
      cy
    });
  }

  // reset transform for safety
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;

  requestAnimationFrame(animate);
}

requestAnimationFrame(animate);
